#' Pengujian Anova Satu Arah
#'
#' Fungsi digunakan untuk menentukan keputusan terkait uji anova satu arah.
#' Peringatan: hanya digunakan untuk jumlah observasi tiap populasi sama.
#'
#' @param data data frame dengan populasi sebagai kolom dan observasi sebagai baris
#' @param alpha tingkat signifikansi (default 0.05)
#' @return Uji Anova satu arah disertai perhitungan

#' @export
test.anova <- function( data = "data frame", alpha = 0.05 ){
  # Dimensi data
  n <- dim(data)[1]
  k <- dim(data)[2]

  # Sum and mean per population
  total.i <- apply(data,2,sum)
  mean.i <- apply(data,2,mean)

  # Sum and mean for total population
  y.. <- sum(total.i)
  ybar.. <- mean(mean.i)

  # Calculating JKP JKT JKG
  jkt <- sum(data^2) - (y..^2)/(k*n)
  jkp <- sum(total.i^2)/n - (y..^2)/(k*n)
  jkg <- jkt - jkp

  # Make new data
  data.2 <- rbind(data,total.i,mean.i)
  rownames(data.2)[dim(data.2)[1]-1] <- "y i."
  rownames(data.2)[dim(data.2)[1]] <- "ybar i."

  sumber.keragaman <- c("Between", "Galat", "Total")
  jumlah.kuadrat <- c(round(jkp,4), round(jkg,4), round(jkt,4))
  derajat.bebas <- c( k-1, (n-1)*k, k*n - 1)
  kuadrat.tengah <- c( jkp/(k-1), jkg/((n-1)*k), NA)
  ano <- data.frame(sumber.keragaman, jumlah.kuadrat, derajat.bebas, kuadrat.tengah)

  f.hit <- (jkp/(k-1))/(jkg/(k*(n-1)))
  f <- qf(alpha, k-1, k*(n-1), lower.tail = F)

  cat("                       Anova satu arah by yoursunshine\n\n\n\n")

  cat(" H0    : rata-rata sama \n",
      "H1    : minimal satu pasang tidak sama \n",
      "alpha : ", alpha, "\n",
      "Wilayah kritik: f hitung > ", round(f,4), "\n",
      "f hitung  : ", round(f.hit,4),"\n",
      "Keputusan : ", ifelse(f.hit>f, "tolak H0: f hitung > f tabel", "Gagal tolak H0: f hitung < f tabel"), "\n\n\n\n",
      "Hasil Perhitungan: \n\n")

  show(data.2)
  cat("\n y..    = ", y.., "\n",
      "ybar.. = ", round(ybar..,4), "\n\n\n")
  cat(" Perhitungan JKT, JKP, JKG, dkk: \n \n")
  ano
}

