# statitest
R Package to find somethin good

use me!


what is this package?
